 $( function() {
     "use strict";
    $( "#accordion" ).accordion();
  } );